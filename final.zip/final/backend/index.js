const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const mysql = require("mysql");
app.use(bodyParser.urlencoded({extended:true}));

//To set up mysql Connection
let connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "mysql2309MJ@",
    database: "endSemWhatsApp"
});
connection.connect(function(err){
    if(err){
        console.log(err);
        throw err;
    }
    console.log("Connection Established with Mysql");
})
function getTime(){
    var date = new Date();
    var hours = date.getHours();
    var mins = date.getMinutes();
    if(hours<12){
        hours = hours+1;
        return hours+":"+mins+" AM";
    }
    else{
        hours = hours-12;
        return hours+":"+mins+" PM";
    }
}
var randomId = 0;
function getID(ans){
    return randomId+1;
}

//A function to run the basic things of our sql.
function basic(){
    var query = "CREATE ROLE admin;";
    connection.query(query,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        console.log("Created Role Admin.");
    });
    var query1 = "grant insert, delete, drop on userGroup to admin;";
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        console.log("Granted Privileges to admin.");
    });
    for (let i = 501; i < 1500; i++) {
        var query2 = "update Message set sent = '1' where messageID = ?";
        connection.query(query2,[i],function(err,result){
            if (err) {
                return console.error('error: ' + err.message);
            }
        });
        i = i + 1;
        if(i == 1500){
            console.log(i);
        }
      }
}
basic();

// This is a map to store all the passwords.

//To Register
app.get("/register",function(req,res){
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/Register.html");
})
app.post("/register",function(req,res){
    var fname = req.body.fname;
    var lname = req.body.lname;
    var phnumber = req.body.phnumber;
    var time = getTime();
    var values = [[fname,lname,phnumber,time,1]];
    var query1 = "insert into Users(firstName, lastName, phoneNumber, creationTime, isActive) values ?";
    if(phnumber.length != 10){
        res.send("Invalid Phone Numer. Not of 10 digits.");
    }
    else{
        connection.query(query1,[values],function(err,result){
            if (err) {
                console.log("Yes here.");
                return console.error('error: ' + err.message);
            }
            res.send("You have been registered.");
            console.log("Query executed");
        });
    }

})

//To login
app.get("/login",function(req,res){
    res.sendFile("/Users/mayankjha/Desktop/final/backend/Login/index.html");
})
app.post("/login",function(req,res){
    var fname = req.body.fname;
    var lname = req.body.lname;
    var no = req.body.number;
    connection.query("Select * from Users where phoneNumber = ?;",[no],(err,result) => {
            if(err){
                console.log(err);
                res.send("No user with those credentials.");
            }
            if(result.length > 0){
                res.send("Welcome, You are logged in.");
            }
            else{
                console.log("There is no such person.");
                res.send("No user with those credentials.")
            }
        });
})

//To get all Contacts
app.get("/contacts",function(req,res){
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/contact.html");
})
app.post("/contacts",function(req,res){
    var values = [[req.body.id]];
    const query1 = "select * from Contacts where user1ID ="+values+" or user2ID = "+values;
    connection.query(query1,[values],function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify(result));
        console.log("Query executed");
    });
});

//To get all chats
app.get("/chats",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/chat.html");
})
app.post("/chats",function(req,res){
    var id1 = req.body.id1;
    var id2 = req.body.id2;
    //Need to make the sent as 1.
    var query0 = "select * from Message where (creatorID = "+id1+" and receiverID = "+id2+") UNION select * from Message where  (receiverID = "+id2+" and creatorID = "+id1+");"
    connection.query(query0,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
    });
    var query1 = "select * from myChats";
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify(result));
        console.log("Query executed");
    });
})

//To get all mutual groups of two people
app.get("/mutual",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/mutual.html");
})
app.post("/mutual",function(req,res){
    var id1 = req.body.id1;
    var id2 = req.body.id2;
    var query0 = "select * from group_ where groupID in (select x.groupID from userGroup as x,userGroup as y where (x.groupID = y.groupID) and (x.userID = "+id1+" and y.userID = "+id2+"));"
    connection.query(query0,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(result);
        console.log("Query complete.");
    });
    console.log("Seems to have failed.");
})


//To get all the participants of a group
app.get("/groupParticipants",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/groupParticipants.html");
})
app.post("/groupParticipants",function(req,res){
    var num = req.body.gid;
    var query0 = "create or replace view groupParticipants as select * from Users where idNumber in (select userID from userGroup where groupID = "+num+");";
    connection.query(query0,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
    });
    var query1 = "select * from groupParticipants";
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify(result));
        console.log("Query executed");
    });
})

//To get the number of participants in a group
app.get("/noOfParticipants",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/noOfparticipants.html");
})
app.post("/noOfParticipants",function(req,res){
    var id = [[req.body.id]];
    var gid = req.body.gid;
    
    const query1 = "Select count(userID) From userGroup Where groupID="+gid;
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify(result));
        console.log("Query executed");
    });

})

//To create a new group
app.get("/createGroup",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/createGroup.html");
})
app.post("/createGroup",function(req,res){
    var name = req.body.gname;
    var time = getTime();
    var id = req.body.id;
    var values = [[name,time,id]];
    var name = req.body.name;
    var query1 = "insert into group_ (name,creationTime,adminID) values ?;";
    connection.query(query1,[values],function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send("Created Group.");
        console.log("Query executed. Group formed.");
    });
    var query2 = "insert into userGroup (userID,groupID) select adminID,groupID from group_ where groupID = (select max(groupID) from group_);";
    connection.query(query2,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        console.log("Added group to tables.");
    });
    var query3 = "Grant admin to "+name;
    console.log(name);
    connection.query(query2,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        console.log("Role granted.");
    });
    
})

//Start chatting with another user
app.get("/startchat",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/startChat.html");
})
app.post("/startchat",function(req,res){
    var msg = req.body.msg;
    var id1 = req.body.id1;
    var id2 = req.body.id2;
    var time = getTime();

    console.log("Here")
    var values = [[msg,time,id1,id2,true]];
    var query1 = "insert into Message (messageBody,creationTime,creatorID,receiverID,sent) values ?;";
    connection.query(query1,[values],function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        console.log("Query executed");
        res.send("The message has been added.");
    });
    var query2 = "insert into Chat (user1ID,user2ID,messageID,creationTime) select creatorID,receiverID,messageID,creationTime from Message where messageID = (select max(messageID) from Message);";
    connection.query(query2,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        console.log("Query executed");
    });
})

//To add participant to a group.
app.get("/addPart",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/AddParticipants.html");
})
app.post("/addPart",function(req,res){
    var gid = req.body.gid;
    var id = req.body.id2;
    var query1 = "insert into userGroup(userID,groupID) values("+id+","+gid+");";
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify("The addition has been done."));
        console.log("Query executed");
    });
})

//To remove someone from a group
app.get("/removeFromgroup",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/RemoveFromGrp.html");
})
app.post("/removeFromgroup",function(req,res){
    var gid = req.body.gid;
    var id = req.body.id;
    var query1 = "delete from userGroup where userID = "+id+" and groupID = "+gid+";";
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify("The removal has been done."));
        console.log("Query executed");
    });
})

//To exit a group
app.get("/exitGroup",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/ExitGrp.html");
})
app.post("/exitGroup",function(req,res){
    var gid = req.body.gid;
    var id = req.body.id;
    var query1 = "delete from userGroup where userID = "+id+" and groupID = "+gid+";";
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify("The removal has been done."));
        console.log("Query executed");
    });
})





//To sort a group chat
app.get("/sortgroupchat",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/SortGrpChat.html");
})
app.post("/sortgroupchat",function(req,res){
    var gid = req.body.gid;
    var query1 = "select * from message where groupId = ? order by creationTime;";
    connection.query(query1,[gid],function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify(result));
        console.log("Query executed");
    });
})
//To get all groupChats
app.get("/groupChats",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/groupChat.html");
})
app.post("/groupChats",function(req,res){
    var gid = req.body.gid;
    var query1 = "select * from Message where exists(select messageID from groupChat where Message.groupID = "+gid+" and groupChat.groupID = "+gid+");";
    connection.query(query1,function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send(JSON.stringify(result));
        console.log("Query executed");
    });
})
//Starting group chatting 
app.get("/startgroupchat",function(req,res){
    //To change later
    res.sendFile("/Users/mayankjha/Desktop/final/backend/html/startGroupChat.html");
})
app.post("/startgroupchat",function(req,res){
    var msg = req.body.msg;
    var id = req.body.id;
    var gid = req.body.gid;
    var t = getTime();
    var values = [[msg,t,id,null,"1",gid]];
    var query1 = "insert into Message (messageBody,creationTime,creatorID,receiverID,sent,GROUPID) values ?;";
    connection.query(query1,[values],function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send("The message has been sent.");
        console.log("Query executed. Group Chat started.");
    });
    var query2 = "insert into groupChat(groupID,creationTime) values ?;";
    var values1 = [[gid,t]];
    connection.query(query2,[values1],function(err,result){
        if (err) {
            return console.error('error: ' + err.message);
        }
        res.send("The message has been sent.");
        console.log("Query executed. Group Chat started.");
    });
})
//------------------------------------------------------------------------
app.listen(3002,()=>{console.log("The server setup is done on 3002.");})