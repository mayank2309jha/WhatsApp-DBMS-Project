import React from "react";

function AddPart(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/addPart" target = "_blank">Add Participants</a>
        </div>
    );
}

export default AddPart;