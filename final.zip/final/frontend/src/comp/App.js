import '../App.css';
import Contact from "./Contacts";
import Chats from "./Chat";
import GChat from "./groupChat";
import GroupPart from "./GroupPart";
import NumberOfPart from "./NoOfPart";
import CreateGroup from "./CreateGroup";
import StartChat from './StartChat';
import StartGroupChat from './StartGroupChat';
import Login from './Login';
import AddPart from "./AddPart.js";
import Register from "./Register";
import RemoveFromGro from './RemoveFromGro';
import ExitGroup from './ExitGroup';
import SortGrpChat from './SortGrpChat';
import Mutual from './mutual';

function App() {
  return (
    <div className="App">
    <Register/>
    <Login/>
    <Contact/>
    <Chats/>
    <StartChat/>

    <Mutual />
    <GChat/>
    <CreateGroup/>
    <AddPart/>
    <GroupPart/>
    <NumberOfPart/>
    <StartGroupChat/>
    <RemoveFromGro/>
    <ExitGroup/>
    <SortGrpChat/>

    </div>
  );
}

export default App;
