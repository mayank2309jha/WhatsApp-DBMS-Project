import React from "react";

function Chats(){
    return(
        <div className = "box success view">
        <a href = "http://localhost:3002/chats" target = "_blank">All Chats</a>
        </div>
    );
}

export default Chats;