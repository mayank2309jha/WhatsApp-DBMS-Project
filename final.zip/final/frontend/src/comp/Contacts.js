import React from "react";

function Contacts(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/contacts" target = "_blank">All Contacts</a>
        </div>
    );
}

export default Contacts;