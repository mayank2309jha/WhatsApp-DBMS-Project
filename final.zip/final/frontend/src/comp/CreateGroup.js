import React from "react";

function CreateGroup(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/createGroup" target = "_blank">Create a group</a>
        </div>
    );
}

export default CreateGroup;