import React from "react";

function Exists(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/exists" target = "_blank">Whether another user exists in a group.</a>
        </div>
    );
}

export default Exists;