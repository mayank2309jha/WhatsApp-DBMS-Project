import React from "react";

function ExitGroup(){
    return(
        <div class = "box success">
            <a href = "http://localhost:3002/exitgroup" target = "_blank">Exit a group.</a>
        </div>
    );
}

export default ExitGroup;