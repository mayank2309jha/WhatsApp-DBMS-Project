import React from "react";

function GroupPart(){
    return(
        <div className = "box success view">
        <a href = "http://localhost:3002/groupParticipants" target = "_blank">All participants in a group</a>
        </div>
    );
}

export default GroupPart;