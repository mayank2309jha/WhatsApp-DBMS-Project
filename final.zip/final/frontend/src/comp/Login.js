import React from "react";

function Login(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/login" target = "_blank">Login</a>
        </div>
    );
}

export default Login;