import React from "react";

function NoOfpart(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/noOfParticipants" target = "_blank">No. of participants in a group</a>
        </div>
    );
}

export default NoOfpart;