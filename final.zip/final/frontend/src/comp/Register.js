import React from "react";

function Register(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/register" target = "_blank">Register</a>
        </div>
    );
}

export default Register;