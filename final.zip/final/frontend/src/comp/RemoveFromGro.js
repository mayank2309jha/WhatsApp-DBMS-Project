import React from "react";

function RemoveFromGro(){
    return(
        <div class = "box success">
            <a href = "http://localhost:3002/removeFromgroup" target = "_blank">Remove from Group.</a>
        </div>
    );
}

export default RemoveFromGro;