import React from "react";

function SortGrpChat(){
    return(
        <div class = "box success">
            <a href = "http://localhost:3002/sortgroupchat" target = "_blank">Sort Group Chat</a>
        </div>
    );
}

export default SortGrpChat;