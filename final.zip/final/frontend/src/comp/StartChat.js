import React from "react";

function StartChat(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/startchat" target = "_blank">Start a chat</a>
        </div>
    );
}

export default StartChat;