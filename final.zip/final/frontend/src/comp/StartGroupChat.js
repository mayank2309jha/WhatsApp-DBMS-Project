import React from "react";

function StartGroupChat(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/startgroupchat" target = "_blank">Start Group Chat</a>
        </div>
    );
}

export default StartGroupChat;