import React from "react";

function groupChat(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/groupChats" target = "_blank">All Group Chats</a>
        </div>
    );
}

export default groupChat;