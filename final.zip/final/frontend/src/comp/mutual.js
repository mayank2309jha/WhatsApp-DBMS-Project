import React from "react";

function mutual(){
    return(
        <div className = "box success">
        <a href = "http://localhost:3002/mutual" target = "_blank">Mutual Groups of 2 people</a>
        </div>
    );
}

export default mutual;